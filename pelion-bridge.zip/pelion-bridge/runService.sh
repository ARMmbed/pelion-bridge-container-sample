#!/bin/sh

# set -x 

#
# Stack and Heap Adjustments for the bridge
#
export SMALL_MEMORY_SIZE_ARGS="-Xms512m -Xmx512m -Xss512k"
export MEDIUM_MEMORY_SIZE_ARGS="-Xms768m -Xmx768m -Xss1024k"
export LARGE_MEMORY_SIZE_ARGS="-Xms1024m -Xmx1024m -Xss4096k"

#
# Choose which size for your bridge's JVM...
#
# export JVM_MEMORY_ARGS="${SMALL_MEMORY_SIZE_ARGS}"

#
# Clear out any old logs - they've already been archived...
#
rm -f ${HOME}/service/logs/*.log > /dev/null 2>&1

#
# Run from the service/target directory!
#
cd ${HOME}/service/target

#
# Product Specification
#
export PRODUCT_NAME="pelion-bridge"
export PRODUCT_VERSION="1.0"

#
# JVM Invocation
#
java ${JVM_MEMORY_ARGS} -Dconfig_file="../conf/service.properties" -jar ${PRODUCT_NAME}-${PRODUCT_VERSION}.war > ../logs/${PRODUCT_NAME}.log 2>&1
